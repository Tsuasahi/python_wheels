# flake8: noqa
__version__ = "0.4.6"

from moabb.utils import set_log_level
